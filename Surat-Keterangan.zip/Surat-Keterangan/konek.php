<?php
date_default_timezone_set('Asia/Jakarta');
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'skripsi_surat';

$konek = mysqli_connect($hostname, $username, $password, $database);
